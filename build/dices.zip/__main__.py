from Core.Controller import Controller

Controller().run()
