from src.Core.Controller import Controller

Controller().run()
